import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OptionsPanel here.
 * 
 * @author Alstion Lin
 * @version Beta 2.1
 */
public class OptionsPanel extends Actor
{
    public OptionsPanel() {
        GreenfootImage image = new GreenfootImage("GameOptionsPanel.png");
        setImage(image);
    }
}

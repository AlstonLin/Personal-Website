import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * A simple background for the UI
 * 
 * @author Jesmin Hondell
 * @version 1.0
 */
public class UIBackground extends Actor
{
}

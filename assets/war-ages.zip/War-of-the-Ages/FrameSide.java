import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Has no functionality; the only purpose of this is to
 * display the image. 
 * 
 * @author Alston Lin
 * @version Beta 2.1
 */
public class FrameSide extends Actor
{
}
